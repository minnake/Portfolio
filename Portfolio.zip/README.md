# Portfolio

 Omien koodaustaitojen portfoliosivusto, jossa on käytetty HTML- ja CSS-kieltä. Tarkoituksena on lisätä toiminnallisuuksia PHP- ja Javascriopt-kielillä.
 
 Tarkoituksena on näyttää tämän hetkinen osaaminen ja tulen jatkamaan sivun tekemistä aina, kun olen oppinnut jotain uutta. 

